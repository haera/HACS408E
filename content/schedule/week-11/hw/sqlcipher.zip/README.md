# SQLCipher

How to use:

```sh
LD_PRELOAD=./libsqlcipher.so.0 ./sqlcipher --help
```

Make sure the `LD_PRELOAD` environment variable is set to the `libsqlcipher`
library included in the zip file!
